export class Piloto {
    constructor(nombre, equipo, numero, nacionalidad){
        this.nombre = nombre;
        this.equipo = equipo;
        this.numero = numero;
        this.nacionalidad = nacionalidad; 
    }
}