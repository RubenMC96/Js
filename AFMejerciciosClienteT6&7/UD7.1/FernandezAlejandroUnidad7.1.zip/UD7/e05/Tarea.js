export class Tarea {
    constructor(texto, realizada){
        this.texto = texto;
        this.realizada = false;
    };
}