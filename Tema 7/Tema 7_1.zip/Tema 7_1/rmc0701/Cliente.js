export default class Cliente {
  constructor(nombre, localidad, cuota) {
    this.nombre = nombre;
    this.localidad = localidad;
    this.cuota = cuota;
  }

  
}
export { Cliente };
