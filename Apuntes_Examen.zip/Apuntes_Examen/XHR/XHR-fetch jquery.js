JSON
function mostrar() {
    $.ajax({
      url: "clientes.json",
      dataType: "json",
      success: function(json) {
        clientes = [...json];
        ejecuta();
      },
      error: function(jqXHR, textStatus, errorThrown) {
        alert("Ha ocurrido un error");
      }
    });
  }

  XML
  function inicio() {
    $.ajax({
      url: "Discos.xml",
      dataType: "xml",
      success: function(xmlDoc) {
        cargarXML(xmlDoc);
      },
      error: function(jqXHR, textStatus, errorThrown) {
        alert("Ha ocurrido un error");
      }
    });
  }

  function inicio() {
    $.ajax({
      url: "Discos.xml",
      dataType: "text",
      success: function(xmlString) {
        let parser = new DOMParser();
        let xmlDoc = parser.parseFromString(xmlString, "application/xml");
        cargarXML(xmlDoc);
      },
      error: function() {
        alert("Se ha producido un error");
      }
    });
  }
  
