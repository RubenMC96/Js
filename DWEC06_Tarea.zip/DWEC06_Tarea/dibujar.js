document.addEventListener('DOMContentLoaded', iniciar, false);


function iniciar(){

    // Obtener el contenedor principal donde se insertará el tablero
    let container = document.getElementById("zonadibujo");
   
   
    // Crear el tablero
    for (let i = 0; i < 30; i++) {
      for (let j = 0; j < 30; j++) {
          // Crear una nueva celda
          let cell = document.createElement("div");
          cell.style.width = "10px";
          cell.style.height ="10px";
   
          // Agregar la celda al contenedor principal
          container.appendChild(cell);
      }
    }
   
    
    let colors = ["color1", "color2", "color3", "color4", "color5"];
   
    // letiable para rastrear si el ratón está presionado
    let isMouseDown = false;
   
    // Función para manejar el clic en una celda
    function celdaSelected(e) {
      // Obtiener el color del botón seleccionado
      let selectedColor = colors.find(color => color.selected);
   
      // Aplicar el color a la celda
      e.style.backgroundColor = selectedColor;
    }
   
    // Controlador de eventos para mousedown
    function ratonPulsado() {
      isMouseDown = true;
      messageElement.textContent = "PINCEL ACTIVADO";
    }
   
    // Controlador de eventos para mouseover
    function ratonSobreCelda(e) {
      if (!isMouseDown) return;
   
      // Obtiene el color del botón seleccionado
      let selectedColor = colors.find(color => color.selected);
   
      // Aplica el color a la celda
      e.style.backgroundColor = selectedColor;
    }
   
    // Controlador de eventos para mouseup
    function ratonDespulsado() {
      isMouseDown = false;
      messageElement.textContent = "PINCEL DESACTIVADO";
    }
   
    // Obtiener el elemento para mostrar el mensaje
    let messageElement = document.getElementById("message");
   
    // Agregar el controlador de eventos a todas las celdas
    container.addEventListener("click", celdaSelected);
    container.addEventListener("mousedown", ratonPulsado);
    container.addEventListener("mouseover", ratonSobreCelda);
    container.addEventListener("mouseup", ratonDespulsado);
}
    
   